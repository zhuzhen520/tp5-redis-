<?php
namespace app\api\model;
use think\Model;

/**
* 商城订单
*/
class OrderInfo extends Model
{
    
} 