<?php
namespace app\api\model;
use think\Model;

/**
* 注册model
*/
class Register extends Model
{
    
    
}
