<?php
namespace app\api\model;
use think\Model;

/**
* 产品数据模型
*/
class Product extends Model
{
    
    
}