<?php
namespace app\api\model;
use think\Model;

/**
* 积分
*/
class IntegralLog extends Model
{
    
    
}