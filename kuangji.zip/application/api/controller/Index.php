<?php
namespace app\api\controller;
use think\Controller;
use think\Request;
use think\loader;
use think\Validate;
use think\Cache;
use think\Db;

class Index extends Controller
{   
    /*会员登陆*/
    public function index()
    {           
        if(Request::instance()->isPost()){
            $data = input('post.');

            $validate = loader::validate('Member');
            if(!$validate->check($data)){            
                return json(['status'=>'n','info'=>$validate->getError()]);
            }
            //实例化
            $model = new \app\api\model\Member;

            $member = $model->where(['username'=>$data['username']])->find();

            if($member){
                if($member['is_login'] == 1){
                    return json(['status'=>'n','info'=>'账号已冻结']);
                }

                $password = md5(md5($data['password']).md5($member['entry']));
                //登陆成功
                if( $password == $member['password'] ){
                    $token = $this->setToken($member['id'],$member['username']);

                    return json(['status'=>'y','info'=>'登陆成功','token'=>$token]);
                }   
            }
            return json(['status'=>'n','info'=>'账号或密码错误']);

        }else{
            return json(['status'=>'n','info'=>'出现错误~','code'=>'400']);
        }
        
    }

    /*设置token*/
    protected function setToken($uid,$username){
        $time   = time();
        $member = md5(md5($uid).md5($username));
        $token  = md5($member.$time);
        $time_limit = 86400*7; //设置有效时间
        $value = [
            'uid'      => $uid,
            'username' => $username,
            'time'     => $time + $time_limit,
        ];
        Cache::set($token,$value,$time_limit);
        return $token;
    }

    /*退出登陆*/
    public function logout($token){
        $b = Cache::rm($token);
        return json(['status'=>$b]);
    }

    /* 注册 */
    public function register(){
        if(Request::instance()->isPost()){
            $data = input('post.');
            $data['mobile'] = $data['username'];
            //验证
            $validate = loader::validate('Register');
            if(!$validate->check($data)){
                return json(['status'=>'n','info'=>$validate->getError()]);
            }

            //验证短信
            $vailSms = $this->vailSms($data['username'],$data['sms_code']);
            if($vailSms['status'] == 'n'){
                return json($vailSms); //错误返回
            }

            //动态验证
            $parent = Db::name('member')->where(['username'=>$data['code']])->find();
            if(empty($parent)){
                return json(['status'=>'n','info'=>'邀请码不存在']);
            }

            $entry = get_rand_str();
            $reg_data = [
                'username'       => $data['username'],
                'password'       => md5(md5($data['password']).md5($entry)),
               'mobile'         => $data['username'],
               'entry'          => $entry,
               'parent_id'      => $parent['id'],
              'parent_mobile'  => $parent['username'],
                'token'          => $data['PayToken'],
                'wallet_address' => $data['username'],
            ];
            $member = new \app\api\model\Member($reg_data);
            $b = $member->save();
            return json(['status'=>$b?'y':'n','info'=>$b?'注册成功':'注册失败']);
        }
    }

    /* 发送短信 */
    public function sendSms($forget=false,$phone=''){
        $phone = input('post.phone')?:$phone;

        if(!preg_match("/^1[345678]{1}\d{9}$/",$phone)){  
            return json(['status'=>'n','info'=>'请输入正确手机号']);
        }

        if(Db::name('member')->where(['username'=>$phone])->find() && $forget == false){
            return json(['status'=>'n','info'=>'账号已注册']);
        }
        import('sms/sendSms', EXTEND_PATH);
        $Sms = new \Think\Sms;
        $code = rand(100000,999999);
        $result = $Sms->sendSms($code,$phone);
        //发送成功
        if($result->Message == "OK"){
            $value = [
                'SMS_code'  => $code,
                'SMS_phone' => $phone,
            ];
            Cache::set($phone,$value,280);
            return json(['status'=>'y','info'=>'发送短信成功']);
        }
        // print_r($result);die;
        return json(['status'=>'n','info'=>'已发送成功,请查收!']);
    }

    /* 验证短信码 */
    public function vailSms($phone,$code){

        $Sms = Cache::get($phone); //验证码缓存
        if(empty($Sms)){
            return ['status'=>'n','info'=>'请先获取验证码'];
        }
        if( $Sms['SMS_code'] != $code ){
            return ['status'=>'n','info'=>'短信验证码错误'];
        }

    }

    /* 忘记密码 */
    public function forget(){
        $data = input('post.');
        if($data['password'] && strlen($data['password']) >= 6 ){

            if($data['sms_code']){
                //验证短信验证码
                $sms = $this->vailSms($data['username'],$data['sms_code']);
                if($sms['status'] == 'n'){
                    return json($sms);
                }
            }else{
                //发送短信验证码
                if($data['username'] && Db::name('member')->where(['username'=>$data['username']])->find()){
                    $sendSms = $this->sendSms(true,$data['username']);
                    return json($sendSms);
                }else{
                    return json(['status'=>'n','info'=>'账号未注册']);
                }
            }
            $entry    = get_rand_str();
            $password = md5(md5($data['password']).md5($entry));
            $b = Db::name('member')->where(['username'=>$data['username']])->update(['entry'=>$entry,'password'=>$password]);
            return json(['status'=>$b,'info'=>$b?'修改密码成功':'操作失败']);
        }else{
            return json(['status'=>'n','info'=>'密码格式错误']);
        } 

    } 

}
