<?php
namespace app\admin\controller;
use think\Request;
use think\loader;
use think\Config;
use think\Cache;
use think\Log;
use think\Db;

class Member extends Base{
    /*会员列表*/
    public function member_list(){
        $db = Db::name('member');
        $where = [];

        $input = input('param.');

        //排序
        if($input['gold_sort']){
            $order['gold_static'] = $input['gold_sort'];
        }
        if($input['id_sort']){
            $order['id'] = $input['id_sort'];
        }

        /* 日期查询 */
        $time_min = $input['start'];
        $time_max = $input['end'];

        if(!empty($time_max) && !empty($time_min)){
            $time_max = strtotime($time_max);
            $time_min = strtotime($time_min);
            /* 两个都填 between 范围内 */
            if($time_max >= $time_min){
                $where['reg_time'] = ['between',[$time_min,$time_max]];
            }else{
                $where['reg_time'] = ['between',[$time_max,$time_min]];
            }
        }elseif(!empty($time_min)){
            $time_min = strtotime($time_min);
            $time_max = !empty($time_max) ? strtotime($time_max) : time()+999999999;
            /* 只填开始时间 */
            $where['reg_time'] = ['between',[$time_min,$time_max]];
        }elseif(!empty($time_max)){
            $time_max = strtotime($time_max);
            /* 只填结束时间 elt小于等于 */
            $where['reg_time'] = ['elt',$time_max];
        }

        //where
        switch ($input['member_type']) {
            case 'admin':
                $where['is_admin'] = 1;
            break;
            case 'trade':
                $where['is_trade'] = 1;
            break;
        }

        //等级
        if(is_numeric( $input['level'] )){
            $where['level'] = $input['level'];
        }

        if($input['word']){
            $where['id|username|mobile'] = $input['word'];
        }

        if($input['parent_id']){
            $where['parent_id'] = $input['parent_id'];
        }

        $list = $db->where($where)->order($order)->paginate(50,false,['query'=>request()->param()]);
        $this->assign('list', $list);
        $this->assign('count', $db->where($where)->count());
        $this->assign('page', $list->render());
        $this->assign('role',Config::get('role'));
        return $this->fetch();
    }

    /*会员编辑*/
    public function member_add(){
        $id = input('id/s');
        $row = Db::name('member')->find($id);

        if(Request::instance()->isPost()){
            $data = input('post.');
            $data['is_trade'] = input('post.is_trade',0);
            $data['is_admin'] = input('post.is_admin',0);
            $data['is_login'] = input('post.is_login',0);

            if($data['rid_speed'] > 1){
                return json(['status'=>'n','info'=>'释放速度不能超过1']);
            }

            if($data['id'] > 0){
                //修改密码
                if( strlen($data['password']) >= 6){
                    $data['entry'] = get_rand_str();
                    $member = loader::model('Member');
                    $b = $member->save($data,['id'=>$data['id']]);
                }else{
                    unset($data['password']);
                    $b = Db::name('member')->update($data);
                }

                $data_log = [
                        'uid'         => $row['id'],
                        'username'    => $row['username'],
                        'add_time'    => time(),
                        'info'        => '管理员操作',
                        'action_type' => 100 , //管理员操作
                    ];

                //金币日志
                if($row['gold'] != $data['gold'] ){
                    $action = $data['gold'] - $row['gold'];
                    $data_log['action'] = abs($action);
                    $data_log['money_end'] = $data['gold'];
                    $data_log['type'] = $action > 0 ? 1:0;
                    Db::name('gold_log')->insert($data_log);
                }
                //积分日志
                if($row['integral'] != $data['integral'] ){
                    $action = $data['integral'] - $row['integral'];
                    $data_log['action'] = abs($action);
                    $data_log['money_end'] = $data['integral'];
                    $data_log['type'] = $action > 0 ? 1:0;
                    Db::name('integral_log')->insert($data_log);
                }

                //升级
                $apiBase = new \app\api\controller\Base;
            }else{
                //没有添加会员功能
                // $b = Db::name('member')->insert($data);
            }

            if($b !== false){
                return json(['status'=>'y','info'=>'操作成功']);
            }else{
                return json(['status'=>'n','info'=>'操作失败！']);
            }

        }else{
            //打开时日志 提交在base
            Log::write($row, 'admin', true);
            $role = Config::get('role');
            $this->assign($row);
            $this->assign('role',$role);
            return $this->fetch();
        }
    }

    /* 线下入金 */
    public function member_money(){
        $id = input('uid');
        $row = Db::name('member')->where(['id'=>$id])->find();

        if(Request::instance()->isPost()){
            $data = input('post.');
            $action = input('post.action/f');

            $action_name = []; //操作者
            foreach(config('action_password') as $pass){
                if( md5(md5($data['password']).'token') == $pass['pass'] ){
                    $action_name = $pass;
                }
            }

            if(!$action_name){ return json(['status'=>'n','info'=>'操作密码错误']); }

            if( $action ){

                if( !Db::name('member')->where(['id'=>$id])->setInc('money',$action) ){
                    return json(['status'=>'n','info'=>'操作失败']);
                }

                $data_log = [
                    'uid'         => $row['id'],
                    'username'    => $row['username'],
                    'action'      => abs($action),
                    'money_end'   => $row['money'] + $action,
                    'info'        => ($data['info'] ? : '线下充值').'['.$action_name['name'].']',
                    'order_sn'    => '',
                    'type'        => $action > 0 ? 1 : 0,
                    'action_type' => 1, //下线后台充值
                    'add_time'    => time()
                ];
                Db::name('money_log')->insert($data_log);
                return json(['status'=>'y','info'=>'操作成功']);
            }
        }else{
            $this->assign($row);
            return $this->fetch();
        }
    }

    /* 安全中心 */
    public function member_info(){
        $uid = input('uid');
        if(Request::instance()->isPost()){
            $data = input('post.');
            // print_r($data);
            $b = Db::name('member_info')->where(['id'=>$data['id']])->update($data);
            if($b !== false){
                return json(['status'=>'y','info'=>'操作成功']);
            }else{
                return json(['status'=>'y','info'=>'操作失败！']);
            }
        }else{
            $member_info = Db::name('member_info')->where(['uid'=>$uid])->find();
            $member_info['member_card'] = Db::name('member_card')->where(['uid'=>$uid])->select();
            $this->assign('member_info',$member_info);
            return $this->fetch();  
        }
    }

    /* 静态金币释放 */
    public function gold_rid(){
        $db = Db::name('static_gold_rid');
        $input = input('param.');
        $where = [];

        if($input['word']){
            $where['uid|username'] = $input['word'];
        }

        $list = $db->where($where)->order('id DESC')->paginate(10,false,['query'=>request()->param()]);

        $this->assign('list', $list);
        $this->assign('count', $db->where($where)->count());
        $this->assign('page', $list->render());
        return $this->fetch();
    }

    /* 积分提现 */
    public function put_integral(){
        $db = Db::name('put_integral');
        $where = [];
        $list = $db->where($where)->order('id DESC')->paginate(10);
        $this->assign('list', $list);
        $this->assign('count', $db->where($where)->count());
        $this->assign('page', $list->render());
        return $this->fetch();
    }

    /* 操作积分提现 */
    public function put_integral_add(){
        if(Request::instance()->isPost()){
            $data = input('post.');
            switch($data['status']){
                case '5':
                    $b = Db::name('put_integral')
                    ->where(['id'=>$data['id']])
                    ->update([
                        'order_sn' => $data['order_sn'],
                        'status'   => 5,
                    ]);
                break;

                case '3':   
                    $put_integral = Db::name('put_integral')->where(['id'=>$data['id'],'status'=>0])->find();
                    if(empty($put_integral)){
                        return json(['status'=>'n','info'=>'已驳回或已成功~']);
                    }

                    $member = Db::name('member')->where(['id'=>$put_integral['uid']])->find();
                    Db::startTrans();
                    try {
                        //会员到账
                        $b = Db::name('member')
                        ->where(['id'=>$put_integral['uid']])
                        ->update([
                            'put_integral' => $member['put_integral'] + $put_integral['action'],
                        ]);

                        if( !$b ){
                            throw new \Exception("会员到账失败");
                        }

                        //订单记录
                        if( !Db::name('put_integral')->where(['id'=>$put_integral['id']])->update(['status'=>3,'info'=>$data['order_sn']]) ){
                            throw new \Exception("提现订单失败");
                        }

                        //可提限日志
                        if(!Db::name('put_integral_log')->insert([
                            'uid'         => $put_integral['uid'],
                            'username'    => $put_integral['username'],
                            'action'      => $put_integral['action'],
                            'money_end'   => $member['put_integral'] + $put_integral['action'],
                            'info'        => '可提积分提现返回',
                            'order_sn'    => $put_integral['id'],
                            'type'        => 1,
                            'action_type' => 3,
                            'add_time'    => time(),
                        ])){
                            throw new \Exception("添加日志失败,请稍后再试"); 
                        }

                        // 提交
                        Db::commit();

                    }catch(\Exception $e) {
                        // 回滚事务
                        Db::rollback();
                        return json(['status'=>'n','info'=>$e->getMessage()]);
                    }
                break;
            }

            return json(['status'=>$b?'y':'n','info'=>$b?'操作成功':'操作失败!']);

        }else{
            return $this->fetch();
        }
    }

    /* 会员结构 */
    public function member_tree(){
        $member = Cache::get('member_tree')?:[];
        $list = member_tree($member);
        $this->assign('data',json_encode($list[0],true));
        return $this->fetch();
    }
    public function empty_data(){
        Cache::set('member_tree',null);
    }

    /* 复投明细 */
    public  function gold_static_gold(){
        $where = [];

        $input = input('param.');
        if($input['word']){
            $where['uid'] = $input['word'];
        }

        $list = Db::name('gold_static_gold')->order('id DESC')->where($where)->paginate(50,false,['query'=>request()->param()]);

        $this->assign('list',$list);
        $this->assign('count',Db::name('gold_static_gold')->where($where)->count());
        $this->assign('page',$list->render());
        return $this->fetch();
    }

    public function member_gold_static(){
        $id = input('uid');
        $row = Db::name('member')->where(['id'=>$id])->find();

        if(Request::instance()->isPost()){
            $data = input('post.');
            $action = input('post.action/f');

            $action_name = []; //操作者
            foreach(config('action_password') as $pass){
                if( md5(md5($data['password']).'token') == $pass['pass'] ){
                    $action_name = $pass;
                }
            }

            if(!$action_name){ return json(['status'=>'n','info'=>'操作密码错误']); }

            if(!is_numeric($data['Today']) || $data['Today'] <= 0){
                return json(['status'=>'n','info'=>'今日交易价错误']);
            }

            if( $action ){

                if( !Db::name('member')->where(['id'=>$id])->setInc('gold_static',$action) ){
                    return json(['status'=>'n','info'=>'操作失败']);
                }

                //静态金币日志   当时价放订单号字段
                $data_log = [
                    'uid'         => $row['id'],
                    'username'    => $row['username'],
                    'action'      => abs($action),
                    'money_end'   => $row['gold_static'] + $action,
                    'info'        => '管理员操作',
                    'order_sn'    => $data['Today'],
                    'type'        => $action > 0 ? 1 : 0,
                    'action_type' => 100, //后台拨币
                    'add_time'    => time()
                ];
                Db::name('gold_static_log')->insert($data_log);

                //升级 及均价
                $apiBase = new \app\api\controller\Base;

                return json(['status'=>'y','info'=>'操作成功']);
            }
        }else{
            $this->assign($row);
            return $this->fetch();
        }
    }

}