<?php
namespace app\admin\controller;
use think\Db;
use think\Request;

/**
* 交易中心管理
*/
class Trade extends Base
{   
    /*交易列表*/
    public function trade_list(){
        $db = Db::name('trade_order');
        $input = input('param.');

        $where = [];

        if($input['trade_type'] > 0){
            $where['trade_type'] = $input['trade_type'];
        }
        if($input['type']){
            $where['type'] = $input['type'];
        }

        /* 日期查询 */
        $time_min = $input['time_min'];
        $time_max = $input['time_max'];

        if(!empty($time_max) && !empty($time_min)){
            $time_max = strtotime($time_max);
            $time_min = strtotime($time_min);
            /* 两个都填 between 范围内 */
            if($time_max >= $time_min){
                $where['start_time'] = ['between',[$time_min,$time_max]];
            }else{
                $where['start_time'] = ['between',[$time_max,$time_min]];
            }
        }elseif(!empty($time_min)){
            $time_min = strtotime($time_min);
            $time_max = !empty($time_max) ? strtotime($time_max) : time()+999999999;
            /* 只填开始时间 */
            $where['start_time'] = ['between',[$time_min,$time_max]];
        }elseif(!empty($time_max)){
            $time_max = strtotime($time_max);
            /* 只填结束时间 elt小于等于 */
            $where['start_time'] = ['elt',$time_max];
        }

        $list = $db->where($where)->order('add_time desc')->paginate(10,flase,['query'=>request()->param()]);
        $count = $db->where($where)->count();
        $this->assign('list',$list);
        $this->assign('page',$list->render());
        $this->assign('count',$count);
        return $this->fetch();
    }

    /*商城订单*/
    public function shop_order(){
        $db = Db::name('order_info');
        /* where 条件初始化 */
        $where = [];
        /* 状态查询 */
        $state = input('state');
        if($state > 0){
            switch ($state) {
                case 1:$where['state'] = 2;break;
                case 2:$where['pay_state'] = 1;break;
                case 3:$where['shipping_state'] = 1;break;
                case 4:$where['shipping_state'] = 3;break;
                case 5:$where['shipping_state'] = 2;break;
                case 6:$where['pay_state'] = 0;break;
                case 7:$where['pay_state'] = 1;$where['shipping_state']=0;break;
            }
        }
        /* 关键词查询 */
        $word = trim(input('word'));
        if(!empty($word)){
            $where['user_id|username|order_sn'] = ['like',"%$word%"];
        }
        /* 日期查询 */
        $time_min = input('time_min');
        $time_max = input('time_max');
        
        if(!empty($time_max) && !empty($time_min)){
            $time_max = strtotime($time_max);
            $time_min = strtotime($time_min);
            /* 两个都填 between 范围内 */
            if($time_max >= $time_min){
                $where['add_time'] = array('between',array($time_min,$time_max));
            }else{
                $where['add_time'] = array('between',array($time_max,$time_min));
            }
        }elseif(!empty($time_min)){
            $time_min = strtotime($time_min);
            $time_max = !empty($time_max) ? strtotime($time_max) : time()+999999999;
            /* 只填开始时间 */
            $where['add_time'] = array('between',array($time_min,$time_max));
        }elseif(!empty($time_max)){
            $time_max = strtotime($time_max);
            /* 只填结束时间 elt小于等于 */
            $where['add_time'] = array('elt',$time_max);
        }
        // var_dump($where);

        $count = $db->where($where)->count();
        /* 分页 */
        $list = $db->where($where)->order('add_time desc')->paginate(10,false,['query'=>request()->param()]);

        $this->assign('total',$db->sum('total'));
        $this->assign('list',$list);
        $this->assign('page',$list->render());
        $this->assign('count',$count);
        return $this->fetch();
    }

    /*价格走势*/
    public function price_trend(){
        $db = Db::name('OrderTrend');

        $count = $db->where($where)->count();
        $list = $db->where($where)->order('dates DESC')->paginate(10);

        $this->assign('count',$count);
        $this->assign('list',$list);
        $this->assign('page',$list->render());
        return $this->fetch();
    }

    //走势图
    public function chart(){
        $list = Db::name('OrderTrend')->select();
        $dates = '';
        $prices = '';
        foreach($list as $v){
            $dates .= "'".$v['dates']."',";
            $prices .= $v['price'].',';
        }
        $this->assign('dates',trim($dates,','));
        $this->assign('prices',trim($prices,','));
        return $this->fetch();
    }

    public function add_order_trend(){
        $db = Db::name('OrderTrend');
        if(Request::instance()->isPost()){
            $data = input('post.');
            //日期转时间
            $data['date_time'] = strtotime($data['dates']);

            if($data['id'] > 0){
                $b = $db->update($data);
            }else{
                $data['add_time'] = time();
                $b = $db->insert($data);
            }
            #结果
            if($b !== flase){
                return json(['status'=>'y','info'=>'操作成功']);
            }else{
                 return json(['status'=>'n','info'=>'操作失败!']);
            }
        }else{
            $id = input('id',0);
            $row = $db->find($id);
            $this->assign('row',$row);
            return $this->fetch();
        }
    }

    public function order_show(){
        $id = input('id');
        $row = Db::name('order_info')->find($id);
        $row['order_goods'] =  Db::name('order_goods')->where(array('order_id'=>$id))->select();

        $this->assign('row',$row);
        return $this->fetch();
    }

    /*订单状态改变*/
    public function order_oper(){
        $order_id = input('order_id');
        $oper = input('oper');
        $db = Db::name('order_info');
        //查询订单的全部状态
        $row = $db->field('state,pay_state,shipping_state')->find($order_id);
        switch($oper){
                /* 确认订单 */
            case 'confirm': 
                if($row['state'] == 1){
                    return json(['status'=>'n','info'=>'该订单已经确认过了']);
                }
                if($row['state'] == 2){
                    return json(['status'=>'n','info'=>'该订单已经取消']);
                }
                $b = $db->where(array('order_id'=>$order_id))->setField('state',1);
            break;
                /* 取消订单 */
            case 'cancel':
                #'0提交1确认2取消',
                if($row['state'] == 2){
                    return json(['status'=>'n','info'=>'该订单已经取消']);
                }
                #物流状态 '0未发货1已发货2已收货3已退货',
                if($row['shipping_state'] > 0){
                    return json(['status'=>'n','info'=>'该订单已经发货,不能取消']);
                }
                $data = ['state'=>2,'cancel_time'=>time()];
                $b = $db->where(['order_id'=>$order_id])->update($data);
            break;
                /* 发货 */
            case 'send':
                #'0未付款1已付款',
                if($row['state'] == 2){
                    return json(['status'=>'n','info'=>'该订单已经取消']);
                }
                if($row['pay_state'] == 0){
                    return json(['status'=>'n','info'=>'该订单未付款']);
                }
                if($row['shipping_state'] > 0){
                    return json(['status'=>'n','info'=>'该订单已经发货']);
                }
                $data = ['state'=>1,'shipping_state'=>1,'send_time'=>time()];
                $b = $db->where(['order_id'=>$order_id])->update($data);
                break;
            case 'refunds': 
                if($row['shipping_state'] == 0){
                    return json(['status'=>'n','info'=>'该订单未发货']);
                }
                if($row['shipping_state'] == 3){
                    return json(['status'=>'n','info'=>'该订单已经退货']);
                }
                $data = array('state'=>1,'shipping_state'=>3,'enfunds_time'=>time());
                $b = $db->where(['order_id'=>$order_id])->update($data);
            break;
        }
        // dump($b);
        if($b){
            return json(['status'=>'y','info'=>'操作成功']);
        }else{
            return json(['status'=>'n','info'=>'操作失败!']);
        }
    }

}