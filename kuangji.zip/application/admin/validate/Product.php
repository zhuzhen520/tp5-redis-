<?php
namespace app\admin\validate;
use think\Validate;
/**
* 产品验证器
*/
class Product extends Validate
{
    
    protected $rule = [
        'name'         => 'require', //商品名称
        'stock'        => 'number|between:0,10000', //库存
        'content'      => 'require', // 内容
        'market_price' => 'number', //市场价
        'shop_price'   => 'number', //商城价
    ];
    protected $message = [
        'name.require'        => '必须填写商品名称',
        'stock.number'        => '库存错误',
        'stock.between'       => '库存数量错误(0~10000)',
        'content.require'     => '必须填写内容',
        'market_price.number' => '市场价错误',
        'shop_price.number'   => '商城价错误',
    ];
}