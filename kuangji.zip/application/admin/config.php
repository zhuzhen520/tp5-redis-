<?php
//配置文件
return [
    //auth权限控制配置
    'AUTH_CONFIG' => [
        'AUTH_ON'           => true,                      // 认证开关
        'AUTH_TYPE'         => 1,                         // 认证方式，1为实时认证；2为登录认证。
        'AUTH_GROUP'        => 'think_auth_group',        // 用户组数据表名
        'AUTH_GROUP_ACCESS' => 'think_auth_group_access', // 用户-用户组关系表
        'AUTH_RULE'         => 'auth_rule',         // 权限规则表
        'AUTH_USER'         => 'think_admin'             // 用户信息表
    ],
    //不需要验证的控制器
    'no_auth_controller' =>['Main','Base'],

    // +----------------------------------------------------------------------
    // | 日志设置
    // +----------------------------------------------------------------------

    'log'                    => [
        // 日志记录方式，内置 file socket 支持扩展
        'type'  => 'File',
        // 日志保存目录
        'path'  => LOG_PATH,
        // 日志记录级别
        'level' => ['notice'],
        // 独立日志
        'apart_level' => ['admin','member'],
    ],

    //操作密码
    'action_password' => [
        [
            'name' => 'zengliangkeji',
            'pass' => md5(md5('123456').'token'),
        ],
        [   
            'name' => 'admin',
            'pass' => md5(md5('111111').'token'),
        ]
    ],

];