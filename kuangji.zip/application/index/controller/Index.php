<?php
namespace app\index\controller;

class Index
{
    public function register(){
        // dump(input('code'));
        
        return view();
    }
}